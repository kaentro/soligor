## LoftSchool example project

### Доступные команды

* `npm install` - установить зависимости
* `npm run prepare` - запустить тесты и проверить стиль кода
* `npm run test` - запустить тесты
* `npm run codestyle` - проверить стиль кода
* `npm run start` - запустить встроенный сервер и следить за изменениями файлов
* `npm run build` - собрать проект в папку `build`
