import assert from 'assert';

describe('Test', () => {
    it('should work', () => {
        assert.isTrue(true);
    });
});
